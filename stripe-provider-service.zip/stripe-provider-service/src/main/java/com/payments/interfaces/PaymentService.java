package com.payments.interfaces;

import com.payments.pojo.CreatePaymentRequest;
import com.payments.pojo.PaymentResponse;

public interface PaymentService {
	
	public PaymentResponse createPayment(CreatePaymentRequest createPaymentRequest);


}
