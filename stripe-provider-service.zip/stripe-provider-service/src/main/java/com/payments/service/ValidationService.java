package com.payments.service;

import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.payments.constant.ErrorCodeEnum;
import com.payments.exception.StripeProviderException;
import com.payments.pojo.CreatePaymentRequest;
import com.payments.pojo.line_items;

@Service
public class ValidationService {

    /**
     * Validate CreatePaymentRequest fields. On first validation failure throws
     * StripeProviderException with a specific error code (30001, 30002, ...),
     * one-line message and appropriate HttpStatus.
     *
     * If all validations pass, returns normally (void).
     */
    public void isValid(CreatePaymentRequest req) {
        if (req == null) {
            String errorCode = ErrorCodeEnum.REQUEST_BODY_REQUIRED.getCode();
            String errorMessage = ErrorCodeEnum.REQUEST_BODY_REQUIRED.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        if (req.getSuccess_url() == null || req.getSuccess_url().trim().isEmpty()) {
            String errorCode = ErrorCodeEnum.MISSING_SUCCESS_URL.getCode();
            String errorMessage = ErrorCodeEnum.MISSING_SUCCESS_URL.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        // Validate success_url format (must be a valid http/https URL)
        if (!isValidUrl(req.getSuccess_url())) {
            String errorCode = ErrorCodeEnum.INVALID_SUCCESS_URL.getCode();
            String errorMessage = ErrorCodeEnum.INVALID_SUCCESS_URL.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        if (req.getCancel_url() == null || req.getCancel_url().trim().isEmpty()) {
            String errorCode = ErrorCodeEnum.MISSING_CANCEL_URL.getCode();
            String errorMessage = ErrorCodeEnum.MISSING_CANCEL_URL.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        // Validate cancel_url format (must be a valid http/https URL)
        if (!isValidUrl(req.getCancel_url())) {
            String errorCode = ErrorCodeEnum.INVALID_CANCEL_URL.getCode();
            String errorMessage = ErrorCodeEnum.INVALID_CANCEL_URL.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        if (req.getLine_items() == null || req.getLine_items().isEmpty()) {
            String errorCode = ErrorCodeEnum.LINE_ITEMS_EMPTY.getCode();
            String errorMessage = ErrorCodeEnum.LINE_ITEMS_EMPTY.getMessage();
            HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
            throw new StripeProviderException(errorCode, errorMessage, httpStatus);
        }

        for (int i = 0; i < req.getLine_items().size(); i++) {
            line_items item = req.getLine_items().get(i);
            if (item == null) {
                String errorCode = ErrorCodeEnum.LINE_ITEM_NULL.getCode();
                String errorMessage = ErrorCodeEnum.LINE_ITEM_NULL.formatMessage(i);
                HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
                throw new StripeProviderException(errorCode, errorMessage, httpStatus);
            }

            if (item.getCurrency() == null || item.getCurrency().trim().isEmpty()) {
                String errorCode = ErrorCodeEnum.LINE_ITEM_CURRENCY_MISSING.getCode();
                String errorMessage = ErrorCodeEnum.LINE_ITEM_CURRENCY_MISSING.formatMessage(i);
                HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
                throw new StripeProviderException(errorCode, errorMessage, httpStatus);
            }

            if (item.getProduct_name() == null || item.getProduct_name().trim().isEmpty()) {
                String errorCode = ErrorCodeEnum.LINE_ITEM_PRODUCT_NAME_MISSING.getCode();
                String errorMessage = ErrorCodeEnum.LINE_ITEM_PRODUCT_NAME_MISSING.formatMessage(i);
                HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
                throw new StripeProviderException(errorCode, errorMessage, httpStatus);
            }

            if (item.getUnit_amount() <= 0) {
                String errorCode = ErrorCodeEnum.LINE_ITEM_UNIT_AMOUNT_INVALID.getCode();
                String errorMessage = ErrorCodeEnum.LINE_ITEM_UNIT_AMOUNT_INVALID.formatMessage(i);
                HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
                throw new StripeProviderException(errorCode, errorMessage, httpStatus);
            }

            if (item.getQuantity() <= 0) {
                String errorCode = ErrorCodeEnum.LINE_ITEM_QUANTITY_INVALID.getCode();
                String errorMessage = ErrorCodeEnum.LINE_ITEM_QUANTITY_INVALID.formatMessage(i);
                HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
                throw new StripeProviderException(errorCode, errorMessage, httpStatus);
            }
        }
    }

    // Helper to check URL is syntactically valid and uses http/https
    private boolean isValidUrl(String url) {
        if (url == null) return false;
        String trimmed = url.trim();
        try {
            URL u = new URL(trimmed);
            String proto = u.getProtocol();
            if (proto == null) return false;
            if (!"http".equalsIgnoreCase(proto) && !"https".equalsIgnoreCase(proto)) {
                return false;
            }
            String host = u.getHost();
            return host != null && !host.isEmpty();
        } catch (MalformedURLException e) {
            return false;
        }
    }
}