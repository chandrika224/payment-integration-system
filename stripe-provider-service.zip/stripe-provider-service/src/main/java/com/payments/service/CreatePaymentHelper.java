package com.payments.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.payments.constant.Constant;
import com.payments.constant.ErrorCodeEnum;
import com.payments.exception.StripeProviderException;
import com.payments.http.HttpRequest;
import com.payments.pojo.CreatePaymentRequest;
import com.payments.pojo.line_items;
import com.payments.stripe.CheckoutSessionResponse;
import com.payments.stripe.StripeError;
import com.payments.stripe.StripeErrorResponse;
import com.payments.stripe.util.JsonUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class CreatePaymentHelper {
	
	@Value("${stripe.api.key}")
	public String stripeApiKey;
	
	@Value("${stripe.create.session.url}")
	public String stripeCreateSessionUrl;
	
	private final JsonUtil jsonUtil;
	
	public HttpRequest prepareStripeCreateSessionRequest(
			CreatePaymentRequest createPaymentRequest) {
	
		   HttpHeaders httpHeaders = new HttpHeaders();
		    httpHeaders.setBasicAuth(stripeApiKey, "");
		    httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		    MultiValueMap<String, String> formData =
		            buildSessionRequest(createPaymentRequest);

		    HttpRequest httpRequest = new HttpRequest();
		    httpRequest.setUrl(stripeCreateSessionUrl);
		    httpRequest.setHttpMethod(org.springframework.http.HttpMethod.POST);
		    httpRequest.setHttpHeaders(httpHeaders);
		    httpRequest.setRequestData(formData);

		    return httpRequest;
		}

		private MultiValueMap<String, String> buildSessionRequest(
		        CreatePaymentRequest createPaymentRequest) {

		    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();

		    // Session details
		    formData.add(
		            Constant.CREATE_SESSION_MODE,
		            Constant.CREATE_SESSION_MODE_PAYMENT);

		    formData.add(
		            Constant.CREATE_SESSION_SUCCESS_URL,
		            createPaymentRequest.getSuccess_url());

		    formData.add(
		            Constant.CREATE_SESSION_CANCEL_URL,
		            createPaymentRequest.getCancel_url());

		    // Line items
		    List<line_items> lineItems = createPaymentRequest.getLine_items();

		    for (int i = 0; i < lineItems.size(); i++) {

		        line_items item = lineItems.get(i);

		        formData.add(
		                String.format(
		                        Constant.CREATE_SESSION_LINE_ITEM_PRICE_CURRENCY_FORMAT, i),
		                item.getCurrency());

		        formData.add(
		                String.format(
		                        Constant.CREATE_SESSION_LINE_ITEM_QUANTITY_FORMAT, i),
		                String.valueOf(item.getQuantity()));

		        formData.add(
		                String.format(
		                        Constant.CREATE_SESSION_LINE_ITEM_UNIT_AMOUNT_FORMAT, i),
		                String.valueOf(item.getUnit_amount()));

		        formData.add(
		                String.format(
		                        Constant.CREATE_SESSION_LINE_ITEM_PRODUCT_NAME_FORMAT, i),
		                item.getProduct_name());
		    }

		    log.info("Built form data for Stripe create session request: {}", formData);

		    return formData;
		
	}
	
	public CheckoutSessionResponse processStripeResponse(
			ResponseEntity<String> httpResult) {
		
		//check if httpResult is null
		if (httpResult == null) {
		    throw new StripeProviderException(
		            ErrorCodeEnum.INVALID_STRIPE_RESPONSE_ERROR.getCode(),
		            "Received null response from Stripe",
		            HttpStatus.BAD_GATEWAY);
		}
		

		
		//check if httpResult is 2xx, then convert it to CheckoutSessionResponse
		if (httpResult != null && httpResult.getStatusCode().is2xxSuccessful()) {
			
			String responseBody = httpResult.getBody();
			log.info("Received successful response from Stripe: {}", responseBody);
			
			//convert responseBody to CheckoutSessionResponse
			CheckoutSessionResponse sessionResponse = jsonUtil
					.convertJsonToObject(responseBody, CheckoutSessionResponse.class);
			
			log.info("Successfully converted Stripe response to CheckoutSessionResponse: {}", 
					sessionResponse);
			
			//check if sessionResponse has valid hosted page URL
			if(sessionResponse != null && sessionResponse.getUrl() != null) {
				log.info("Stripe session created successfully with Id: {}, Hosted page URL: {}", 
						sessionResponse.getId(), sessionResponse.getUrl());
			
			return sessionResponse;
			}
		}
			
		//if code comes here means its a failed/error
			//4xx or 5xx
			if(httpResult.getStatusCode().is4xxClientError() || httpResult.getStatusCode().is5xxServerError()) {
			log.error("Stripe API call failed with error response."
					+ " Status code: {}, Response body: {}", 
					httpResult.getStatusCode(), httpResult.getBody());
			
			//use jsonutil to convert the error response body to 
			//StripeErrorResponse object
			StripeErrorResponse stripeErrorResponse = jsonUtil.convertJsonToObject(
					httpResult.getBody(), StripeErrorResponse.class);
			
			if (stripeErrorResponse != null && stripeErrorResponse.getError() != null) {
				log.error("Stripe API error details - Code: {}, Message: {}, Type: {}",
						stripeErrorResponse.getError().getCode(),
						stripeErrorResponse.getError().getMessage(),
						stripeErrorResponse.getError().getType());
				
				String stripeConcatenatedErrorMessage = 
						prepareStripeErrorMessage(stripeErrorResponse);
				log.error("Prepared stripe error message: {}", stripeConcatenatedErrorMessage);
				
				throw new StripeProviderException(
						ErrorCodeEnum.STRIPE_API_ERROR_RESPONSE.getCode(), 
						stripeConcatenatedErrorMessage,
						HttpStatus.valueOf(httpResult.getStatusCode().value()));
				
			} log.error("stripe api call failed with non-json error response status"
						+ " code: {}, body: {}", httpResult.getStatusCode(), httpResult.getBody());
		}
			
			//success object conversion failed
			//no url in the response
			//unable to parse the response body to StripeErrorResponse object
			
			throw new StripeProviderException(
					ErrorCodeEnum.INVALID_STRIPE_RESPONSE_ERROR.getCode(),
					ErrorCodeEnum.INVALID_STRIPE_RESPONSE_ERROR.getMessage(),
					HttpStatus.BAD_GATEWAY
					);
		
		
	}
		
	public String prepareStripeErrorMessage(StripeErrorResponse stripeErrorResponse) {
		
		StripeError error = stripeErrorResponse.getError();
		
		return Stream.of(
				error.getType(),
				error.getMessage(),
				error.getParam(),
				error.getCode()
				)
				.filter(Objects::nonNull)
				.map(String::trim)
				.filter(s -> !s.isEmpty())
				.collect(java.util.stream.Collectors.joining("|"));
	}

}