package com.payments.service;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;

import com.payments.http.HttpRequest;
import com.payments.http.HttpServiceEngine;
import com.payments.interfaces.PaymentService;
import com.payments.pojo.CreatePaymentRequest;
import com.payments.pojo.PaymentResponse;
import com.payments.stripe.CheckoutSessionResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {
	
	private final ValidationService validationService;
	private final CreatePaymentHelper createPaymentHelper;
	private final HttpServiceEngine httpServiceEngine;
	
	@Override
	public PaymentResponse createPayment(CreatePaymentRequest createPaymentRequest) {
		// TODO Auto-generated method stub
		log.info("Processing payment creation logic... createPaymentRequest: {}", 
				createPaymentRequest);
		
		validationService.isValid(createPaymentRequest);
		
		HttpRequest httpRequest = createPaymentHelper
				.prepareStripeCreateSessionRequest(createPaymentRequest);
		
		if (httpRequest == null) {
		    throw new RuntimeException(
		            "prepareStripeCreateSessionRequest() returned null");
		}
		
		
		ResponseEntity<String> httpResult = 
				httpServiceEngine.makeHttpCall(httpRequest);
		
		CheckoutSessionResponse sessionResponse = createPaymentHelper
				.processStripeResponse(httpResult);
		log.info("Processed stripe response into CheckoutSessionResponse: {}", 
				sessionResponse);
		
		PaymentResponse paymentResponse = mapToPaymentResponse(sessionResponse);
		
		return paymentResponse;
	}
	
	/**
	 * write a map method to take CheckoutSessionResponse
	 * and convert it to PaymentResponse which is 
	 * our internal reponse object
	 */
	
	public PaymentResponse mapToPaymentResponse(
			CheckoutSessionResponse sessionResponse) {
		
		if (sessionResponse == null) {
			log.warn("Received null CheckoutSessionResponse, "
					+ "returning null PaymentResponse");
			return null;
		}
		
		PaymentResponse paymentResponse = new PaymentResponse();
		paymentResponse.setStripeSessionId(sessionResponse.getId());
		paymentResponse.setHostedPageUrl(sessionResponse.getUrl());
		
		log.info("Mapped CheckoutSessionResponse to PaymentResponse: {}", 
				paymentResponse);
		
		return paymentResponse;
	}


}