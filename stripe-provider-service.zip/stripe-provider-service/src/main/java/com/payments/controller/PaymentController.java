package com.payments.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payments.http.HttpServiceEngine;
import com.payments.interfaces.PaymentService;
import com.payments.pojo.CreatePaymentRequest;
import com.payments.pojo.PaymentResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/v1/payments")
public class PaymentController {

	private final PaymentService paymentService;
	private final HttpServiceEngine httpServiceEngine;


	@PostMapping
	public PaymentResponse createPayment(@RequestBody CreatePaymentRequest createPaymentRequest) {

		log.info("Received create payment request: {}", createPaymentRequest);
		PaymentResponse paymentResponse = paymentService.createPayment(createPaymentRequest);
		log.info("Payment creation result: {}", paymentResponse);
		return paymentResponse;

	}

	public void init() {
		log.info("PaymentController initialized with PaymentService: {} and HttpServiceEngine: {}", paymentService, httpServiceEngine);
	}
}
