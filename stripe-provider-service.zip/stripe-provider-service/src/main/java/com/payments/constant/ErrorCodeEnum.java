package com.payments.constant;

public enum ErrorCodeEnum {

    REQUEST_BODY_REQUIRED("30001", "Request body is required"),
    MISSING_SUCCESS_URL("30002", "Missing success_url"),
    INVALID_SUCCESS_URL("30003", "Invalid success_url: must be a valid http(s) URL"),
    MISSING_CANCEL_URL("30004", "Missing cancel_url"),
    INVALID_CANCEL_URL("30005", "Invalid cancel_url: must be a valid http(s) URL"),
    LINE_ITEMS_EMPTY("30006", "line_items must contain at least one item"),
    LINE_ITEM_NULL("30007", "line_items[%d] is null"),
    LINE_ITEM_CURRENCY_MISSING("30008", "line_items[%d].currency is required"),
    LINE_ITEM_PRODUCT_NAME_MISSING("30009", "line_items[%d].product_name is required"),
    LINE_ITEM_UNIT_AMOUNT_INVALID("30010", "line_items[%d].unit_amount must be greater than zero"),
    LINE_ITEM_QUANTITY_INVALID("30011", "line_items[%d].quantity must be greater than zero"), 
    GENERIC_ERROR("30000", "An unexpected error occurred"), 
    Error_Connecting_Stripe_External_Service("30012", "Error connecting to Stripe external service"), 
    STRIPE_SERVICE_UNAVAILABLE("30013", "Stripe service is currently unavailable. Please try again later."), 
    STRIPE_API_ERROR_RESPONSE("30020", "<dynamically prepared based on Stripe's error response>"), 
    INVALID_STRIPE_RESPONSE_ERROR("30014", "Invalid response received from Stripe API");

    private final String code;
    private final String messageTemplate;

    ErrorCodeEnum(String code, String messageTemplate) {
        this.code = code;
        this.messageTemplate = messageTemplate;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return messageTemplate;
    }

    // Format message with arguments when messageTemplate contains placeholders
    public String formatMessage(Object... args) {
        if (args == null || args.length == 0) {
            return messageTemplate;
        }
        return String.format(messageTemplate, args);
    }
}
