package com.payments.constant;

public class Constant {
	
	private Constant() {
		// Private constructor to prevent instantiation
	}
	public static final String CREATE_SESSION_SUCCESS_URL = "success_url";
	
	public static final String CREATE_SESSION_CANCEL_URL = "cancel_url";

	// the name of the mode field in Stripe's form
	public static final String CREATE_SESSION_MODE = "mode";
	// possible value for mode
	public static final String CREATE_SESSION_MODE_PAYMENT = "payment";

	// Line item / price related form field format strings
	public static final String CREATE_SESSION_LINE_ITEM_PRICE_CURRENCY_FORMAT = "line_items[%d][price_data][currency]";
	public static final String CREATE_SESSION_LINE_ITEM_QUANTITY_FORMAT = "line_items[%d][quantity]";
	public static final String CREATE_SESSION_LINE_ITEM_PRODUCT_NAME_FORMAT = "line_items[%d][price_data][product_data][name]";
	public static final String CREATE_SESSION_LINE_ITEM_UNIT_AMOUNT_FORMAT = "line_items[%d][price_data][unit_amount]";

}