package com.payments.http;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClient;

import com.payments.constant.ErrorCodeEnum;
import com.payments.exception.StripeProviderException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class HttpServiceEngine {
	
	private final RestClient restClient;
	
	public ResponseEntity<String> makeHttpCall(HttpRequest httpRequest) {
		log.info("Making HTTP call to external service...");
		
		try {
			ResponseEntity<String> response = restClient
					.method(httpRequest.getHttpMethod())
			        .uri(httpRequest.getUrl())
			        .headers(headers ->headers.addAll(httpRequest.getHttpHeaders()))
			        .body(httpRequest.getRequestData())
			        .retrieve()
			        .toEntity(String.class);
			
			
			log.info( "Making HTTP call to external service via restClient...{} ", response);
			return response;
			
		}catch (HttpClientErrorException | HttpServerErrorException ex) {
			//got valid error response from stripe. 4xx or 5xx.
			
			//prepare ResponseEntity with error details from the exception and to the caller.
			ResponseEntity<String> errorResponse = ResponseEntity
					.status(ex.getStatusCode())
			        .headers(ex.getResponseHeaders() != null ? ex.getResponseHeaders() : new HttpHeaders())
			        .contentType(MediaType.APPLICATION_JSON)
			        .body(ex.getResponseBodyAsString());
					
					
			log.error("RestClientException occurred while making HTTP call: {}", ex.getMessage(), ex);
			
			//if we get 503 or 504 then throw StripeProviderException
			if (ex.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE || 
					ex.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
				log.error("Stripe service is unavailable ({}). Throwing StripeProviderException.", ex.getStatusCode());
				throw new StripeProviderException(
						ErrorCodeEnum.STRIPE_SERVICE_UNAVAILABLE.getCode(),
						ErrorCodeEnum.STRIPE_SERVICE_UNAVAILABLE.getMessage(),
						HttpStatus.SERVICE_UNAVAILABLE
						);
			}
			
			return errorResponse;
		}
		catch (Exception ex) {
			log.error("Error making HTTP call: {}", ex.getMessage(), ex);
			
			throw new StripeProviderException(
					ErrorCodeEnum.Error_Connecting_Stripe_External_Service.getCode(),
					ErrorCodeEnum.Error_Connecting_Stripe_External_Service.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR
					);
		}
	
	}
	

}
