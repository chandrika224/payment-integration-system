package com.payments.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.payments.constant.ErrorCodeEnum;
import com.payments.pojo.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(StripeProviderException.class)
    public ResponseEntity<ErrorResponse> handleStripeProviderException(StripeProviderException ex) {
    	log.error("Handling StripeProviderException: {}", ex);
    	
    	HttpStatus httpStatus = ex.getHttpStatus() != null ? ex.getHttpStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    	
        ErrorResponse error = new ErrorResponse();
        error.setErrorCode(ex.getErrorCode());
        error.setErrorMessage(ex.getMessage() != null ? ex.getMessage() : "An error occurred with the Stripe provider");
        
        log.error("StripeProviderException details - ErrorCode: {}, ErrorMessage: {}, HttpStatus: {}", 
				ex.getErrorCode(), 
				ex.getMessage(), 
				httpStatus);
        return new ResponseEntity<>(error, ex.getHttpStatus());
    }
    /*
     * Handle Exception class return ErrorResponse with Generic Error Code and Message and HTTP status 500
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
		log.error("Handling generic exception: {}", ex.getMessage(), ex);
				
		HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(ErrorCodeEnum.GENERIC_ERROR.getCode());
		error.setErrorMessage(ErrorCodeEnum.GENERIC_ERROR.getMessage());
		
		log.error("Generic Exception details - ErrorCode: {}, ErrorMessage: {}, HttpStatus: {}");
		return new ResponseEntity<>(error, httpStatus);
		
    }
}
