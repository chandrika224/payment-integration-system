package com.payments.stripe.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Small utility wrapper around Jackson's ObjectMapper.
 * Provides null-on-exception convenience methods used by the project.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public final class JsonUtil {

    private final ObjectMapper mapper;

    /**
     * Convert JSON string into a Java object of the provided type.
     * Returns null if conversion fails or input is null/empty.
     */
    public <T> T convertJsonToObject(String json, Class<T> clazz) {
        if (json == null || json.trim().isEmpty() || clazz == null) {
            log.debug("convertJsonToObject: null/empty input or null clazz (json present? {})", json != null);
            return null;
        }
        try {
            // use a copy to ensure we don't mutate the injected mapper's config
            ObjectMapper safe = mapper.copy()
                    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return safe.readValue(json, clazz);
        } catch (Exception e) {
            log.error("Failed to convert JSON to {}. JSON: {}", clazz != null ? clazz.getName() : "null", json, e);
            // swallow and return null as per project convention
            return null;
        }
    }

    /**
     * Convert a Java object into its JSON string representation.
     * Returns null if conversion fails or input is null.
     */
    public String convertObjectToJson(Object obj) {
        if (obj == null) {
            log.debug("convertObjectToJson: null object provided");
            return null;
        }
        try {
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("Failed to convert object to JSON: {}", obj, e);
            // swallow and return null as per project convention
            return null;
        }
    }
}