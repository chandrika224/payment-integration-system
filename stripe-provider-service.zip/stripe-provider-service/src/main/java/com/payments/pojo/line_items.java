package com.payments.pojo;

import lombok.Data;

@Data
public class line_items {
	
	private String currency;
	private String product_name;
	private int quantity;
	private int unit_amount; 

}
