package com.payments.pojo;

import java.util.List;

import lombok.Data;

@Data
public class CreatePaymentRequest {
	
	private String success_url;
	private String cancel_url;
	
	private List<line_items> line_items;

}
